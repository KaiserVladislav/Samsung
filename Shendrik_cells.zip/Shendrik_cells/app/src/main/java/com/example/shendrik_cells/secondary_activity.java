package com.example.shendrik_cells;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;

public class secondary_activity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secondary_activity);


        Intent i = getIntent();
        String str = i.getStringExtra(basic_activity.RESULT);
        TextView tv = findViewById(R.id.TV);
        tv.setText(str);

        Button return_button = findViewById(R.id.return_button);
        return_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String end = "Good Ending";
                Intent intent = new Intent();
                intent.putExtra(basic_activity.RESULT,end);
                setResult(RESULT_OK,intent);
                finish();

            }
        });




    }


}
