package com.example.shendrik_cells;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class a2 extends AppCompatActivity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        Toast.makeText(this, "FFFFF", Toast.LENGTH_SHORT).show();
        Button bt1 = findViewById(R.id.button11);
        bt1.setText("asfasfasf");
        Button bt2 = findViewById(R.id.button12);
        Button bt3 = findViewById(R.id.button13);
        Button bt4 = findViewById(R.id.button14);
        Button bt5 = findViewById(R.id.button15);
    }
}
