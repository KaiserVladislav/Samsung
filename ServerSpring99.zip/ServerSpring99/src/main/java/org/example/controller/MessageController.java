package org.example.controller;

import org.example.model.Message;
import org.example.repository.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/messages")
public class MessageController {

    //ArrayList<Message> messages = new ArrayList<>();
    @Autowired
    MessageRepository messageRepository;

    @GetMapping
    public List<Message> getAllMessages(){
        //Message message = new Message(generateID(),"1862 goes rash","AUTHOR");
        //messages.add(message);
        //return messages;
        return messageRepository.findAll();
    }

    @PostMapping
    public Message createMessage(@RequestBody Message message){
        /*
        messages.add(message);
        return message;*/
        messageRepository.saveAndFlush(message);
        return message;
    }

    @PutMapping("{id}")
    public Boolean changeMessage(@PathVariable int id, @RequestBody Message message){
        //return messageRepository.updateMessageById(id,message)

        /*
        for(int i = 0;i<messages.size();i++){
            if(messages.get(i).getId()==id){
                messages.set(i,message);
            }
        }*/
/*
        ArrayList<Message> local = (ArrayList<Message>) messages.stream().filter(it -> {return it.getId()==id;}  ).collect(Collectors.toList());
        if(!local.isEmpty()){
            Message msg = local.get(0);
            message.setId(id);
            messages.set(messages.indexOf(msg), message);

            return true;
        }

        return false;*/

        Message msg = messageRepository.findMessageById(id);
        if(msg!=null){
            message.setId(id);
            messageRepository.saveAndFlush(message);
            return true;
        }
        return false;
    }

    @DeleteMapping("{id}")
    public void deleteMessage(@PathVariable int id){

//        for(int i = 0;i<messages.size();i++){
//            if(messages.get(i).getId()==id){
//                return messages.remove(i);
//            }
//        }
/*
        ArrayList<Message> local = (ArrayList<Message>) messages.stream().filter(it -> {return it.getId()==id;}  ).collect(Collectors.toList());
        if(!local.isEmpty()){
            Message MSG = local.get(0);
            messages.remove(MSG);
            return MSG;
        }
        return null;*/
        //return messageRepository.deleteMessageById(id);
        messageRepository.deleteById(id);

    }

    public static int generateID(){
        return new Random().nextInt(Integer.MAX_VALUE);
    }

}
