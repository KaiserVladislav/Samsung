package org.example.repository;

import org.example.model.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface MessageRepository extends JpaRepository<Message, Integer> {
    public Message findMessageById(int id);
    public Message deleteMessageById(int id);
    //public Message updateMessageById(int id);
}
