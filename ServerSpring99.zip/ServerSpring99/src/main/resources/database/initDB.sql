create table Message(

    id int primary key,
    str text,
    author text

);