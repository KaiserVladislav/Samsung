package com.example.bruh;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.bruh.dao.NoteDAO;
import com.example.bruh.models.Note;

@Database(entities = {Note.class}, version = 1)
public abstract class AppDataBase extends RoomDatabase {
    public abstract NoteDAO noteDAO();
}
