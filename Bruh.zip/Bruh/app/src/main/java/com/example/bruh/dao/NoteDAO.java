package com.example.bruh.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.bruh.models.Note;

import java.util.List;

//Data Access Object
@Dao
public interface NoteDAO {
    // взять значения с таблички
    // * - все поля
    @Query("SELECT * FROM Note_table")
    public List<Note> getNotes();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertNote(Note note);

    @Query("DELETE FROM Note_table WHERE id=:id")
    public void deleteNote(int id);

    @Update(onConflict = OnConflictStrategy.IGNORE)
    public void updateNote(Note note);

}
