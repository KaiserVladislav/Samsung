package com.example.bruh.viewmodel;

import android.content.Context;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.bruh.models.Note;
import com.example.bruh.repo.NoteRepository;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainViewModel extends ViewModel {
    private ExecutorService executorService = Executors.newSingleThreadExecutor();

    private MutableLiveData<String> notesLD = new MutableLiveData<>();
    private NoteRepository noteRepository;

    public void init(Context context){
        noteRepository=new NoteRepository(context);
    }

    public MutableLiveData<String> getNotesLD() {
        return notesLD;
    }

    public void setNotesLD(String notesStr) {
        this.notesLD.postValue(notesStr);
    }

    public void insertClick() {
        executorService.execute(
                ()->{
                    noteRepository.insertNote(new Note("KEKW"));
                }
        );

    }
    public List<Note> getAllNotes(){
        return noteRepository.getListNote();
    }
    public void getAllClick(){
        executorService.execute( ()->{
            notesLD.postValue(getAllNotes().toString());
        } );

    }
}
