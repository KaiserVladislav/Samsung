package com.example.bruh.repo;

import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.bruh.AppDataBase;
import com.example.bruh.dao.NoteDAO;
import com.example.bruh.models.Note;

import java.util.List;

public class NoteRepository {
    NoteDAO noteDAO;

    public NoteRepository(Context context){
        AppDataBase appDataBase = Room.databaseBuilder(context, AppDataBase.class, "MyDB")
                .build();
        noteDAO=appDataBase.noteDAO();
    }

    public List<Note> getListNote(){
        return noteDAO.getNotes();
    }

    public void insertNote(Note note){
        noteDAO.insertNote(note);
    }


}
