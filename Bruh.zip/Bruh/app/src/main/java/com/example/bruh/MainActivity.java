package com.example.bruh;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.bruh.databinding.ActivityMainBinding;
import com.example.bruh.viewmodel.MainViewModel;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MainViewModel mainViewModel = new ViewModelProvider(this)
                .get(MainViewModel.class);
        mainViewModel.init(getApplicationContext());
        ActivityMainBinding activityMainBinding = DataBindingUtil
                .setContentView(this, R.layout.activity_main);

        setContentView(activityMainBinding.getRoot());
        activityMainBinding.setViewmodel(mainViewModel);
        activityMainBinding.invalidateAll();
        activityMainBinding.setLifecycleOwner(this);

        //TextView tv = findViewById(R.id.TV);


//        Button insert = findViewById(R.id.Insert);
//        insert.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mainViewModel.insertClick();
//            }
//        });
//
//        Button getAll = findViewById(R.id.getAll);
//        getAll.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mainViewModel.getAllClick();
//            }
//        });
//
//        mainViewModel.getNotesLD().observe(this, new Observer<String>() {
//            @Override
//            public void onChanged(String s) {
//                tv.setText(s);
//            }
//        });
//
//    }
    }
}