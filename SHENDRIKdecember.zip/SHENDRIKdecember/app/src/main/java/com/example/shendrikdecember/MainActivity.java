package com.example.shendrikdecember;

import
        androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {
    TextView Temp_TV;
    TextView weather_TV;
    EditText city_ET;
    ImageView weather_IMG;
    Button refresh_BT;
    static String city="Oerlikon";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        registerReceiver(receiver,new IntentFilter(GisService.CHANNEL),RECEIVER_EXPORTED);
//
//        Intent intent = new Intent(this, GisService.class);
//        startService(intent);

        Temp_TV = findViewById(R.id.temp_TV);
        weather_TV = findViewById(R.id.weather_TV);
        weather_IMG = findViewById(R.id.weather_IMG);
        city_ET = findViewById(R.id.city_ET);
        refresh_BT = findViewById(R.id.refresh);

        refresh_BT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!city.isEmpty()){
                    city = city_ET.getText().toString();
                }

                registerReceiver(receiver,new IntentFilter(GisService.CHANNEL),RECEIVER_EXPORTED);

                Intent intent = new Intent(getApplicationContext(), GisService.class);
                startService(intent);
            }
        });


    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        Intent intent = new Intent(this, GisService.class);
        stopService(intent);
    }


    public BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            String response = intent.getStringExtra(GisService.INFO);
            Log.d("RESULT", response);

            try {
                JSONObject start = new JSONObject(response);
                JSONObject main = start.getJSONObject("main");
                String temp = main.getString("temp");
                double temperature = Math.round(Double.parseDouble(temp));
                String output = String.format("%.0f",temperature);
                Temp_TV.setVisibility(View.VISIBLE);
                Temp_TV.setText("Temperature: "+output+" celcium");

                JSONArray weather_ar = start.getJSONArray("weather");
                JSONObject weather_st = weather_ar.getJSONObject(0);
                String weather = weather_st.getString("main");
                weather_TV.setVisibility(View.VISIBLE);
                weather_TV.setText("Status: "+weather);

                if(weather.equals("Clouds")){
                    weather_IMG.setBackgroundResource(R.drawable.cloudy);
                }else if(weather.equals("Rain")){
                    weather_IMG.setBackgroundResource(R.drawable.rainy);
                }else if (weather.equals("Smoke")){
                    weather_IMG.setBackgroundResource(R.drawable.smoke);
                }
                else if(weather.equals("Clear")){
                    weather_IMG.setBackgroundResource(R.drawable.sunny);
                }

                weather_IMG.setVisibility(View.VISIBLE);
                //weather_IMG.setBackgroundResource(R.drawable.cloudy);


            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

        }
    };

    public static String getCity() {
        return city;
    }
}