package com.example.shendrikdecember;

import android.os.Handler;
import android.os.Message;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.net.ssl.HttpsURLConnection;

public class HTTPREQUEST implements Runnable {

    public static String api = "https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={API key}";
    public  static final String api_key="248516ad6dea804beb915dbc3e0c294a";
    private android.os.Handler handler;
    public static final String city = "Oerlikon";
    private URL url;

    public HTTPREQUEST(Handler h)  {
        handler=h;
        try {
            url = new URL("https://api.openweathermap.org/data/2.5/weather?q="+city+"&appid="+api_key+"&units=metric");
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public void run() {
        try {
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            Scanner in = new Scanner(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            while (in.hasNext()){
                response.append(in.nextLine());
            }
            in.close();
            connection.disconnect();
            Message msg = Message.obtain();
            msg.obj = response.toString();
            handler.sendMessage(msg);


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
