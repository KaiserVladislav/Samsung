package com.example.shendrik_mailing_orders;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.shendrik_mailing_orders.databinding.CoolMarketBinding;

import java.util.ArrayList;

public class CoolMarket extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cool_market);

        CoolMarketBinding binding = CoolMarketBinding.inflate(getLayoutInflater());

        binding.contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+binding.phone.getText().toString()));
                startActivity(intent);
            }
        });

        binding.SendReviewBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message ="You ordered:\n";
                ArrayList<CheckBox> checkBoxes = new ArrayList<>();
                checkBoxes.add(findViewById(R.id.Lemons));
                checkBoxes.add(findViewById(R.id.Tangerines));
                checkBoxes.add(findViewById(R.id.Oranges));
                checkBoxes.add(findViewById(R.id.Apples));
                checkBoxes.add(findViewById(R.id.Strawberries));
                checkBoxes.add(findViewById(R.id.Raspberries));

                boolean trigger=false;
                for (int i = 0; i < checkBoxes.size(); i++) {
                    if(checkBoxes.get(i).isChecked()){
                        message+=checkBoxes.get(i).getText().toString()+"\n";
                        trigger=true;
                    }
                }
                if(trigger==false){
                    message+="nothing";
                }

                RadioButton delivery = findViewById(R.id.Delivery);
                RadioButton pickup = findViewById(R.id.Pickup);


                if(delivery.isChecked()){
                    message+="You chose: Delivery\n";
                }else if(pickup.isChecked()){
                    message+="You chose: Pickup\n";
                }else{
                    message+="You chose: Nothing...\n";
                }

                message+="Your review was: \n";
                EditText et = findViewById(R.id.Review_ET);
                message+=et.getText().toString();

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setPackage("com.google.android.gm");
                intent.setType("text/plain");
                String email = "grandprinceheavenlysnow@gmail.com";
                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
                intent.putExtra(Intent.EXTRA_SUBJECT, "CoolMarket");
                intent.putExtra(Intent.EXTRA_TEXT, "message");


                try {
                    startActivity(Intent.createChooser(intent, "Choose an Email client :"));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(CoolMarket.this, "No email clients installed.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}