package com.example.shendrik_mailing_orders;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.example.shendrik_mailing_orders.databinding.CoolMarketBinding;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        CoolMarketBinding binding = CoolMarketBinding.inflate(getLayoutInflater());
        binding.getRoot();

        binding.contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+binding.phone.getText().toString()));

                startActivity(intent);
            }
        });
        binding.SendReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:"));
                intent.putExtra(Intent.EXTRA_EMAIL,"idunnoman@gmail.com");
                intent.putExtra(Intent.EXTRA_SUBJECT, "Review");
            }
        });
    }
}