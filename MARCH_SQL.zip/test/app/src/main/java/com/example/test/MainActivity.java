package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private NoteRepository noteRepository;

    private ExecutorService  executorService = Executors.newFixedThreadPool(Integer.MAX_VALUE);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        noteRepository = new NoteRepository(getApplication());
        Button bt = findViewById(R.id.button);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                executorService.execute(
                        ()->noteRepository.insert(new Note(generateId(),"RANDOM NAME"))
                );

                executorService.execute(
                        ()-> noteRepository.getAllNote()
                );
            }
        });

        EditText ed = findViewById(R.id.EDT);
        EditText ed2 = findViewById(R.id.EDT2);

        Button bt2 = findViewById(R.id.button2);
        Button bt3 = findViewById(R.id.button3);

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executorService.execute(
                        ()->noteRepository.deleteById(Integer.parseInt(ed.getText().toString()))
                );
            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executorService.execute(

                        ()-> Log.d("ENTITY BY NAME ", ""+noteRepository.findByName(ed2.getText().toString()).getId())
                );
            }
        });
    }

    public static int generateId(){
        Random random = new Random();
        return random.nextInt(Integer.MAX_VALUE);
    }
}