package com.example.test;

import android.app.Application;
import android.util.Log;

import androidx.room.Room;

import java.util.List;

public class NoteRepository implements NoteDao  {

    private final NoteDao noteDao;

    public NoteRepository(Application application){
        AppDatabase db = Room.databaseBuilder(application.getApplicationContext(),
                AppDatabase.class, "MyDB").build();
        noteDao=db.noteDao();
    }

    @Override
    public List<Note> getAllNote() {

        for(Note e : noteDao.getAllNote()){
            Log.d("NOTE : ", e.toString());
        }

        return noteDao.getAllNote();
    }


    @Override
    public void insert(Note note) {
        noteDao.insert(note);
    }

    @Override
    public void deleteById(int id) {
        noteDao.deleteById(id);
    }

    @Override
    public Note findByName(String name) {
        return noteDao.findByName(name);
    }
}
