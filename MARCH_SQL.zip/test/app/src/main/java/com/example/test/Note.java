package com.example.test;


import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName="Note_table")
public class Note {
    @PrimaryKey
    private int id;

    @ColumnInfo(name="Note_name")
    private String name;

    public Note(int id, String name){
        this.name=name;
        this.id=id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @NonNull
    @Override
    public String toString() {
        return "ID: "+getId()+" NAME: "+ getName();
    }
}
