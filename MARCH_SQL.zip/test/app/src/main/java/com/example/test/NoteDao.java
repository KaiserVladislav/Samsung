package com.example.test;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;
// Data Access Object
@Dao
public interface NoteDao {
    @Query("SELECT * FROM Note_table")
    List<Note> getAllNote();

    @Insert
    void insert(Note note);

    @Query("DELETE FROM Note_table WHERE id=:id")
    void deleteById(int id);

    @Query("SELECT * FROM Note_table WHERE Note_name=:name")
    Note findByName(String name);
}
