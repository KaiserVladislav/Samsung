package com.example.retrofit2;

public class BearerResponse {
    String access_token;
    String token_type;
}
