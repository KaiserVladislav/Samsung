package com.example.retrofit2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Network network = new Network();
    ArrayList<Tag> tags;
    Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        handler=new Handler(){
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                if (msg.obj!=null && msg.obj instanceof List){
                    Log.d("MyMessage", ((List<Tag>) msg.obj).toString() );
                    tags= (ArrayList<Tag>) msg.obj;
                    network.likeTag(tags.get(1).id,handler);
                }
                if(msg.obj!=null && msg.obj instanceof Tag){
                    Log.d("MyTAG", ((Tag) msg.obj).toString() );
                }
            }
        };

        network.getTags(handler);
        network.createTag(handler);

    }

}