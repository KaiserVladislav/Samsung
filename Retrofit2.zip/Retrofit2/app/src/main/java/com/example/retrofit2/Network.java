package com.example.retrofit2;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.List;

import okhttp3.Interceptor;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Network {
    Retrofit retrofit;
    API api;

    String token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4MGJjYTljYy0zZDFkLTRlY2QtOGM3Mi0yYmZjNmM4M2NmNTciLCJhdWQiOlsiZmFzdGFwaS11c2VyczphdXRoIl19.2MhZpukfyL_9D41anUb_Ew2Qld-RgMB_qNfRmUYspO8";

    public Network(){

        OkHttpClient client = new OkHttpClient.Builder().addNetworkInterceptor(new Interceptor() {
            @Override
            public okhttp3.Response intercept(Chain chain) throws IOException {
                Request request = chain.
                        request().
                        newBuilder().
                        addHeader("Authorization", "Bearer "+token).
                        build();
                return chain.proceed(request);
            }
        }).build();


        retrofit = new Retrofit.Builder()
                .client(client)
                .baseUrl("https://maps.rtuitlab.dev/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        api = retrofit.create(API.class);

    }

    public void getTags(Handler handler){
        Call<List<Tag>> call = api.getTags();
        call.enqueue(new Callback<List<Tag>>() {
            @Override
            public void onResponse(Call<List<Tag>> call, Response<List<Tag>> response) {
                Log.d("ANSWER",response.raw().toString());
                Log.d("ANSWERBODY", response.body().toString());

                Message msg = new Message();
                msg.obj=response.body();
                handler.sendMessage(msg);
            }

            @Override
            public void onFailure(Call<List<Tag>> call, Throwable t) {
                Log.d("FAILFAIL", t.toString());
            }
        });
    }


    public void likeTag(String id, Handler handler){
        Call<Tag> call = api.likeTag(id);
        call.enqueue(new Callback<Tag>() {
            @Override
            public void onResponse(Call<Tag> call, Response<Tag> response) {
                Log.d("LIKEEEEE",response.toString());
                Log.d("LIKEEEEEBODY", response.toString());

                Message msg = new Message();
                msg.obj=response.body();
                handler.sendMessage(msg);
            }

            @Override
            public void onFailure(Call<Tag> call, Throwable t) {
                Log.d("LIKEEFAIL", t.toString());
            }
        });
    }

    public void createTag(Handler handler){
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("longitude","1")
                .addFormDataPart("latitude","1")
                .addFormDataPart("destription", "VLADDDDDD")
                .build();
        Call<Tag> call = api.createTag(requestBody);
        call.enqueue(new Callback<Tag>() {
            @Override
            public void onResponse(Call<Tag> call, Response<Tag> response) {
                Log.d("POSSS",response.toString());
                Log.d("POSSSBODY", response.toString());
                Message msg = new Message();
                msg.obj = response.body();
                handler.sendMessage(msg);
            }

            @Override
            public void onFailure(Call<Tag> call, Throwable t) {
                Log.d("POSSSFAIL", t.toString());
            }
        });
    }


}
