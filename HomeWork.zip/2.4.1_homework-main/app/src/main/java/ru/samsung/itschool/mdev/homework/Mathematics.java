package ru.samsung.itschool.mdev.homework;

public class Mathematics {

    static double[] solve_equation(int a, int b, int c){
        double res[] = new double[2];

        double d = Math.pow(b,2)-4*a*c;

        if (a==0 && b==0 && c==0){
            res[0]= Double.MAX_VALUE;
            return res;
        }
        if(a==0){
            if(b==0){
                res[0]=Double.MIN_VALUE;
                return res;
            }
            res[0]=-c/b;
            return res;
        }

        if(d<0){
            res[0]=Double.MIN_VALUE;
            return res;
        }else if(d==0){
            res[0]= -b/2/a;
            return res;
        }
        res[0] = (-b+Math.sqrt(d))/2/a;
        res[1] = (-b-Math.sqrt(d))/2/a;
        return res;
    }

}
