package ru.samsung.itschool.mdev.homework;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText objectA, objectB, objectC;
        objectA=findViewById(R.id.a);
        objectB=findViewById(R.id.b);
        objectC=findViewById(R.id.c);
        TextView res = findViewById(R.id.res);
        Button button = findViewById(R.id.run);





        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = objectA.getText().toString();
                String b = objectB.getText().toString();
                String c = objectC.getText().toString();
                try {
                    int A = Integer.parseInt(a);
                    int B = Integer.parseInt(b);
                    int C = Integer.parseInt(c);
                    double result[] = Mathematics.solve_equation(A,B,C);

                    if(result[0]==Double.MAX_VALUE){
                        res.setText("any");
                    }else if(result[0]==Double.MIN_VALUE){
                        res.setText("none");
                    } else if(result[1]==0){
                        res.setText(result[0]+"");
                    }
                    else {
                        res.setText(result[0]+" "+result[1]);

                    }
            } catch (NumberFormatException e) {
                // Handle the case where the input is not a valid integer
                res.setText("Invalid input. Please enter valid integers");
                return; // Exit the method to avoid further processing with invalid input
            }




            }
        });

    }

}