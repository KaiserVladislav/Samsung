package com.example.shendrik_november;

import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;

import com.example.shendrik_november.databinding.ThirdActivityBinding;

public class ThirdActivity extends AppCompatActivity {
    @Override
    protected void onStart() {
        super.onStart();
        ThirdActivityBinding binding = ThirdActivityBinding.inflate(getLayoutInflater());
        binding.getRoot();

        SharedPreferences mPref  = getPreferences(MODE_PRIVATE);
        String surname = mPref.getString("SURNAME","");
        String name = mPref.getString("NAME","");

        binding.OUTPUT.setText(surname+" "+name);


    }
}
