package com.example.shendrik_november;

public class Person {
    private String surname;
    private String name;
    public Person(String surname, String name){
        this.surname=surname;
        this.name=name;
    }


}
