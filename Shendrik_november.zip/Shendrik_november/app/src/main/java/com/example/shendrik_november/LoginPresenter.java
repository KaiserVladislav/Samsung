package com.example.shendrik_november;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.shendrik_november.databinding.LoginBinding;

public class LoginPresenter {

    private static String TRUE_LOGIN = "1234";
    private static String TRUE_PASSWORD = "1234";

    private LoginBinding loginBinding;
    private Context context;
    private SharedPreferences mPref;

    public LoginPresenter(Context context, LoginBinding loginBinding, SharedPreferences mPref){
        this.loginBinding = loginBinding;
        this.context = context;
        this.mPref = mPref;
    }

    //section 1 - checking if cache exists
    public boolean signInPref(){
        String loginPref = mPref.getString("LOGIN","");
        String passwordPref = mPref.getString("PASSWORD","");
        if(loginPref.equals(TRUE_LOGIN) && passwordPref.equals(TRUE_PASSWORD)){
            return true;
        }
        return false;
    }
    public boolean signIn(){
        SharedPreferences.Editor edit = mPref.edit();

        // section 2 - filling cache
        String login = loginBinding.LoginET.toString();
        String password = loginBinding.PasswordET.toString();

        if(login.equals(TRUE_LOGIN)&&password.equals(TRUE_PASSWORD)){

            edit.putString("LOGIN",login);
            edit.putString("PASSWORD",password);
            edit.commit();
            return true;
        }
        return false;

    }
}
