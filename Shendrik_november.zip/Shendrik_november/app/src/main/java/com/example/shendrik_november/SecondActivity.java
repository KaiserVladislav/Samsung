package com.example.shendrik_november;

import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.shendrik_november.databinding.SecondAcivityBinding;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onStart() {
        super.onStart();
        SecondAcivityBinding binding = SecondAcivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SharedPreferences mPref = getPreferences(MODE_PRIVATE);
        SecondPresenter presenter = new SecondPresenter(this, binding,mPref);

        binding.nextPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                presenter.force_push_people_into_third_activity_wholesome_indeed();
                Intent intent = new Intent(SecondActivity.this, ThirdActivity.class);
                startActivity(intent);
            }
        });


    }
}
