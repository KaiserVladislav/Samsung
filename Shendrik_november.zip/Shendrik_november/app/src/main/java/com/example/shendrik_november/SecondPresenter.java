package com.example.shendrik_november;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.shendrik_november.databinding.LoginBinding;
import com.example.shendrik_november.databinding.SecondAcivityBinding;

public class SecondPresenter {

    private SecondAcivityBinding secondAcivityBinding;
    private Context context;
    private SharedPreferences mPref;

    public SecondPresenter(Context context, SecondAcivityBinding secondAcivityBinding, SharedPreferences mPref){
        this.secondAcivityBinding = secondAcivityBinding;
        this.context = context;
        this.mPref = mPref;
    }

    public void force_push_people_into_third_activity_wholesome_indeed(){
        String name = secondAcivityBinding.NameET.getText().toString();
        String surname = secondAcivityBinding.NameET.getText().toString();
        SharedPreferences.Editor edit = mPref.edit();

        //TODO: edit.put()?;
        Person person = new Person(surname,name);
        edit.putString("SURNAME",surname);
        edit.putString("NAME",name);
    }
}
