package com.example.myapplication.network.api;

import com.example.myapplication.data.models.Result;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface BookSearchService {
    //https://www.googleapis.com/books/v1/volumes?q=1
    @GET("books/v1/volumes?q=1")//необходимо вписать
    Call<Result> searchBooks(
        @Query("q") String query
    );

}
