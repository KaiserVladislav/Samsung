package com.example.myapplication.data.models.room;

import androidx.room.TypeConverter;

import com.example.myapplication.data.models.ImageLinks;
import com.example.myapplication.data.models.Item;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.List;

public class ItemConverter {

   //need converter for List<Item>

   Gson gson = new Gson();
    @TypeConverter
    public String fromItems(List<Item> items) { // items to json (string)
        return gson.toJson(items);
    }

    @TypeConverter
    public List<Item> toItems(String data) { // json (string) to items
        return gson.fromJson(data, new TypeToken<List<Item>>(){}.getType());
        //return gson.fromJson(data, Item.class);
    }

}

